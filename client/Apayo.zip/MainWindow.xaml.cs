﻿using Azure;
using Microsoft.CognitiveServices.Speech;
using Microsoft.Web.WebView2.Core;
using MySqlX.XDevAPI.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Markup;

namespace Apayo
{
    public partial class MainWindow : Window
    {

        

        private SpeechRecognizer recognizer;
        private TcpClient client;
        private NetworkStream stream;


        public String myid; // 로그인한아이디
        public String myname; // 클릭한 닉네임
        public String address; // 서버에서 받은 주소

        public double X_CDN;
        public double Y_CDN;
        private Dictionary<CheckBox, Func<Hospital, bool>> cbFilters = new();
        private List<Hospital> allHospitals = new List<Hospital>();

        public MainWindow()
        {
            InitializeComponent();
            ConnectToServer();
            FillDateComboBoxes();
            MyTabControl.SelectedIndex = 8;

            var style = new Style(typeof(TabItem));
            style.Setters.Add(new Setter(TabItem.VisibilityProperty, Visibility.Collapsed));
            MyTabControl.ItemContainerStyle = style;

            IdTextBox.Text = "아이디를 입력해주세요";
            IdTextBox.Foreground = Brushes.Gray;

            this.Width = 420;
            this.Height = 800;

            // 크기 조절 불가
            this.ResizeMode = ResizeMode.NoResize;

            // 이벤트 등록
            IdTextBox.GotFocus += IdTextBox_GotFocus;
            IdTextBox.LostFocus += IdTextBox_LostFocus;
        }
        private void IdTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (IdTextBox.Text == "아이디를 입력해주세요")
            {
                IdTextBox.Text = "";
                IdTextBox.Foreground = Brushes.Black; // 일반 텍스트 색으로 변경
            }
        }
        private void PasswordTextBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            UpdatePasswordPlaceholderVisibility();
        }

        private void PasswordTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            UpdatePasswordPlaceholderVisibility();
        }

        private void PasswordTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            UpdatePasswordPlaceholderVisibility();
        }
        private void FillDateComboBoxes()
        {
            // 연도: 예) 1900년 ~ 2025년까지
            for (int year = 1900; year <= 2025; year++)
            {
                join_YearComboBox.Items.Add(year.ToString());
            }
            join_YearComboBox.SelectedIndex = join_YearComboBox.Items.Count - 1; // 기본값 현재년도

            // 월: 1월 ~ 12월
            for (int month = 1; month <= 12; month++)
            {
                join_MonthComboBox.Items.Add(month.ToString());
            }
            join_MonthComboBox.SelectedIndex = 0;

            // 일: 1일 ~ 31일
            for (int day = 1; day <= 31; day++)
            {
                join_DayComboBox.Items.Add(day.ToString());
            }
            join_DayComboBox.SelectedIndex = 0;
        }

        private void UpdatePasswordPlaceholderVisibility()
        {
            if (PasswordTextBox.IsFocused || !string.IsNullOrEmpty(PasswordTextBox.Password))
            {
                PasswordPlaceholder.Visibility = Visibility.Collapsed;
            }
            else
            {
                PasswordPlaceholder.Visibility = Visibility.Visible;
            }
        }
        private void IdTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IdTextBox.Text))
            {
                IdTextBox.Text = "아이디를 입력해주세요";
                IdTextBox.Foreground = Brushes.Gray; // 안내 문구는 회색으로 표시
            }
        }
        private void AppendOutput(string text)
        {
            Dispatcher.Invoke(() =>
            {
                
            });
        }

        private async void ConnectToServer()
        {
            try
            {
                client = new TcpClient();
                await client.ConnectAsync("10.10.20.109", 10006); // 서버 IP와 포트 조정
                stream = client.GetStream();
                
            }
            catch (Exception ex)
            {
                
            }
        }

        // 클래스 필드로 수신 버퍼 누적용 변수 선언
        private StringBuilder recvBuffer = new StringBuilder();

        private async Task SendTextToServer(string message)
        {
            if (stream == null || !client.Connected)
                return;

            try
            {
                byte[] data = Encoding.UTF8.GetBytes(message + "\n");
                await stream.WriteAsync(data, 0, data.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string recvData = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                recvBuffer.Append(recvData);

                string totalData = recvBuffer.ToString();
                string[] messages = totalData.Split('\n');

                for (int i = 0; i < messages.Length - 1; i++)
                {
                    string jsonStr = messages[i].Trim();
                    if (string.IsNullOrEmpty(jsonStr)) continue;

                    try
                    {
                        using (JsonDocument doc = JsonDocument.Parse(jsonStr))
                        {
                            var root = doc.RootElement;

                            if (root.TryGetProperty("signal", out var signalProp))
                            {
                                string signal = signalProp.GetString();

                                if (signal == "request")
                                {
                                    string serverMessage = root.GetProperty("result").GetString();

                                    Dispatcher.Invoke(() =>
                                    {
                                        AddChatBubble(serverMessage, isFromServer: true);

                                        // ✅ 상담 종료 메시지 감지 시 진단 버튼 보이게
                                        if (serverMessage.Contains("상담이 종료되었습니다. 더 이상 질문을 받을 수 없습니다."))
                                        {
                                            DiagnosisButton.Visibility = Visibility.Visible;
                                        }
                                    });
                                }
                                else if (signal == "save_chat_result")
                                {
                                    // 채팅 저장 완료 신호 수
                                    Console.WriteLine("채팅 저장 완료 응답 받음");
                                    // 필요 시 추가 작업 가능, 현재는 아무 작업 안 함
                                }
                                else
                                {
                                    // 기타 signal 처리
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("JSON 파싱 오류: " + ex.Message);
                        Dispatcher.Invoke(() => AddChatBubble("[응답 파싱 오류]", true));
                    }
                }

                string lastMessage = messages.Length > 0 ? messages[messages.Length - 1] : "";

                recvBuffer.Clear();
                recvBuffer.Append(lastMessage);
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    AddChatBubble("[서버 통신 오류]", isFromServer: true);
                });
            }
        }

        private void AddChatBubble(string message, bool isFromServer)
        {
            var textBlock = new TextBlock
            {
                Text = message,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(10),
                Background = isFromServer ? Brushes.LightBlue : Brushes.LightGray,
                Foreground = Brushes.Black,
                Padding = new Thickness(10),
                MaxWidth = 300
            };

            var border = new Border
            {
                CornerRadius = new CornerRadius(10),
                Background = textBlock.Background,
                Child = textBlock,
                HorizontalAlignment = isFromServer ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(5)
            };

            ChatStackPanel.Children.Add(border);

            // 스크롤 맨 아래로 이동
            ChatScrollViewer.ScrollToEnd();
        }
        private void Recognizer_Recognized(object sender, SpeechRecognitionEventArgs e)
        {
            if (!string.IsNullOrEmpty(e.Result.Text))
            {
                Dispatcher.Invoke(() =>
                {
                    AddChatBubble(e.Result.Text, isFromServer: false); // 👈 왼쪽에 사용자 말 추가
                    OutputTextBox.Text = e.Result.Text;
                });

                var recordObj = new
                {
                    signal = "record",
                    say_text = e.Result.Text
                };

                string json = JsonSerializer.Serialize(recordObj);
                SendTextToServer(json); // 서버 응답 오면 아래에 오른쪽 말풍선으로 붙이기
            }
        }
        private void Recognizer_Canceled(object sender, SpeechRecognitionCanceledEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                OutputTextBox.Text = $" 인식 취소: {e.Reason}";
            });
        }
        private void OutputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }
        private void RecordButton_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void id_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void Join_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 2;
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            if (stream == null || !client.Connected)
            {
                AppendOutput("서버 연결이 없습니다.\n");
                return;
            }

            var loginObj = new
            {
                signal = "login",
                id = IdTextBox.Text.Trim(),
                pw = PasswordTextBox.Password
            };

            string json = JsonSerializer.Serialize(loginObj) + "\n"; // 서버에서 \n 로 자르는 경우
            byte[] data = Encoding.UTF8.GetBytes(json);

            try
            {
                await stream.WriteAsync(data, 0, data.Length);
                AppendOutput($"➡ 로그인 요청 보냄: {json}");

                // JSON 전체 수신을 위한 버퍼 처리
                using (MemoryStream ms = new MemoryStream())
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;

                    do
                    {
                        bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        ms.Write(buffer, 0, bytesRead);
                    } while (stream.DataAvailable); // 남은 데이터가 있으면 계속 읽기

                    string response = Encoding.UTF8.GetString(ms.ToArray()).Trim();

                    try
                    {
                        var doc = JsonDocument.Parse(response);
                        var root = doc.RootElement;

                        if (root.TryGetProperty("signal", out var signalElement) &&
                            signalElement.GetString() == "login_result")
                        {
                            string result = root.GetProperty("result").GetString();

                            if (result == "0") // 로그인 성공
                            {
                                MessageBox.Show("로그인 성공");

                                // 프로필 처리
                                if (root.TryGetProperty("profile", out var profilesElement) &&
                                    profilesElement.ValueKind == JsonValueKind.Array)
                                {
                                    if (root.TryGetProperty("addr", out var addrElement))
                                    {
                                        string addr = addrElement.GetString();
                                        address = addr;
                                        //MessageBox.Show(address);
                                    }

                                    GenerateProfiles(profilesElement);
                                }

                                myid = IdTextBox.Text.Trim();
                                MyTabControl.SelectedIndex = 5;
                            }
                            else if (result == "1")
                            {
                                MessageBox.Show("로그인 실패\n아이디 또는 비밀번호를 확인해주세요.");
                            }
                        }
                        else
                        {
                            MessageBox.Show($"서버에서 예상치 못한 응답 형식: {response}");
                        }

                        doc.Dispose(); // 명시적 해제
                    }
                    catch (JsonException jex)
                    {
                        MessageBox.Show($"JSON 파싱 오류: {jex.Message}\n응답 내용: {Encoding.UTF8.GetString(ms.ToArray())}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"서버 통신 중 오류: {ex.Message}");
            }

            // 로그인 입력 초기화
            IdTextBox.Text = "";
            PasswordTextBox.Clear();
            IdTextBox_LostFocus(null, null);
        }

        public class ProfileInfo
        {
            public string Id { get; set; }
            public string Age { get; set; }
            public string Sex { get; set; }
        }
        private void GenerateProfiles(JsonElement profilesElement)
        {
            Dispatcher.Invoke(() =>
            {
                ProfileStackPanel.Children.Clear();

                foreach (var profile in profilesElement.EnumerateArray())
                {
                    string name = profile.GetProperty("mem_name").GetString();
                    string birth = profile.GetProperty("birth").GetString();  // 문자열로 받음
                    string gender = profile.GetProperty("gender").GetString();

                    StackPanel profilePanel = new StackPanel
                    {


                        Orientation = Orientation.Vertical,
                        Margin = new Thickness(5),
                        Background = Brushes.White,
                    };

                    profilePanel.Children.Add(new TextBlock { Text = $"닉네임: {name}", FontWeight = FontWeights.Bold });
                    profilePanel.Children.Add(new TextBlock { Text = $"생년월일: {birth}" });
                    profilePanel.Children.Add(new TextBlock { Text = $"성별: {gender}" });

                    Border border = new Border
                    {
                        Child = profilePanel,
                        Padding = new Thickness(10),
                        Background = Brushes.White, // 배경 흰색
                        BorderBrush = new SolidColorBrush(Color.FromRgb(230, 230, 230)), // 연한 흰색 (약간 회색 느낌)
                        BorderThickness = new Thickness(1),
                        CornerRadius = new CornerRadius(6),
                        Margin = new Thickness(5)
                    };

                    border.MouseLeftButtonUp += (s, e) =>
                    {
                        myname = name;
                        MyTabControl.SelectedIndex = 10;
                        //MessageBox.Show($"[{name}] 프로필을 선택했습니다.");
                    };

                    ProfileStackPanel.Children.Add(border);
                    UpdateProfileCountLabel();
                }
            });
        }



        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is ProfileInfo profile)
            {
                MessageBox.Show($"선택된 프로필:\nID: {profile.Id}\n나이: {profile.Age}\n성별: {profile.Sex}");

                // 예: 프로필 선택 후 채팅 탭으로 이동
                MyTabControl.SelectedIndex = 5;
            }
        }
        // 뒤로가기 버튼
        private void back_btn_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 0;
        }
        private async void back_btn1_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("저장하고 나가시겠습니까?", "확인", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                // 채팅 내용 수집
                List<string> chatMessages = new List<string>();

                foreach (var item in ChatStackPanel.Children)
                {
                    if (item is Border border && border.Child is TextBlock textBlock)
                    {
                        chatMessages.Add(textBlock.Text);
                    }
                }

                // 채팅이 하나도 없을 경우 저장하지 않고 메시지 표시
                if (chatMessages.Count == 0)
                {
                    MessageBox.Show("저장할 채팅 내용이 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
                    MyTabControl.SelectedIndex = 3;
                    return; // 함수 종료
                }

                var jsonObj = new
                {
                    signal = "save_chat",
                    name = myname,
                    id = myid,
                    messages = chatMessages
                };

                string jsonString = JsonSerializer.Serialize(jsonObj);
                await SendTextToServer(jsonString);

                MyTabControl.SelectedIndex = 3;


            }
        }

        private async void JoinButton_Click(object sender, RoutedEventArgs e)
        {
            if (stream == null || !client.Connected)
            {
                MessageBox.Show(" 서버 연결이 없습니다.");
                return;
            }

            var joinObj = new
            {
                signal = "join",
                id = join_IdTextBox.Text.Trim(),
                pw = join_PasswordTextBox.Password,
                adress = join_adress.Text.Trim(),
                phone = $"{(join_PhonePrefix.SelectedItem as ComboBoxItem)?.Content?.ToString()}{join_PhoneMiddle.Text.Trim()}{join_PhoneLast.Text.Trim()}",
                gender = join_Gender.Text.Trim(),
                year = $"{join_YearComboBox.Text}-{join_MonthComboBox.Text.PadLeft(2, '0')}-{join_DayComboBox.Text.PadLeft(2, '0')}",
                name = Join_name.Text.Trim(),

            };

            string json = JsonSerializer.Serialize(joinObj) + "\n";

            //Console.WriteLine($"보내는 JSON: {json}");
            //MessageBox.Show($"보내는 JSON:\n{json}");

            byte[] data = Encoding.UTF8.GetBytes(json);

            try
            {
                await stream.WriteAsync(data, 0, data.Length);
                //MessageBox.Show(" 회원가입 요청이 서버에 전송되었습니다.");

                // 서버 응답 받기 
                byte[] buffer = new byte[256];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                var doc = JsonDocument.Parse(response);
                var root = doc.RootElement;

                string signal = root.GetProperty("signal").GetString();
                string result = root.GetProperty("result").GetString();

                // 예: 서버가 0 = 성공, 1 = 실패 응답할 때 처리

                if (signal == "join_success")
                {
                    if (result == "0")
                    {
                        MessageBox.Show("회원가입 성공");
                        MyTabControl.SelectedIndex = 0;
                    }
                    else if (result == "1")
                    {
                        MessageBox.Show("회원가입 실패");
                        MyTabControl.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show($" 알 수 없는 응답: {response}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($" 서버 통신 오류: {ex.Message}");
            }
        }
        private bool isRecognizing = false;

        private async void RecordButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (!isRecognizing)
            {
                string apiKey = "6E7e5wt316M9WHV2yXRS99xxIlhBT8lM1CcxQzUpvsSG2wGl3PL3JQQJ99BGACNns7RXJ3w3AAAYACOGPtwI";
                string region = "koreacentral";

                var config = SpeechConfig.FromSubscription(apiKey, region);
                config.SpeechRecognitionLanguage = "ko-KR";

                recognizer = new SpeechRecognizer(config);

                recognizer.Recognized += Recognizer_Recognized;
                recognizer.Canceled += Recognizer_Canceled;

                await recognizer.StartContinuousRecognitionAsync();

                //OutputTextBox.Text = "말하세요...";
                //RecordButton.Content = "중지"; // 
                isRecognizing = true;
            }
            else
            {
                if (recognizer != null)
                {
                    await recognizer.StopContinuousRecognitionAsync();

                    recognizer.Recognized -= Recognizer_Recognized;
                    recognizer.Canceled -= Recognizer_Canceled;
                    recognizer.Dispose();
                    recognizer = null;

                    //OutputTextBox.Text = "인식 종료됨";
                    //RecordButton.Content = "시작"; // 
                    isRecognizing = false;
                }
            }
        }
        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 1;

            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버 연결이 없습니다.");
                return;
            }

            var resetRequest = new
            {
                signal = "chat_reset",
                id = myid // 너가 쓰는 ID로 바꿔
            };

            string json = JsonSerializer.Serialize(resetRequest) + "\n";
            byte[] data = Encoding.UTF8.GetBytes(json);

            try
            {
                await stream.WriteAsync(data, 0, data.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                var responseObj = JsonSerializer.Deserialize<JsonElement>(response);
                string signal = responseObj.GetProperty("signal").GetString();
                string result = responseObj.GetProperty("result").GetString();

                if (signal == "reset_ok" && result == "0")
                {
                    // ✅ 초기화 성공 시에만 클라이언트 UI 초기화
                    if (ChatStackPanel != null)
                    {
                        ChatStackPanel.Children.Clear();

                        Dispatcher.InvokeAsync(() =>
                        {
                            ChatScrollViewer.ScrollToTop();
                        });
                    }
                    OutputTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("GPT 초기화 실패");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GPT 초기화 요청 중 오류: " + ex.Message);
            }
        }
        private void Record_back_btn_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 3;
        }
        private void UpdateProfileCountLabel()
        {
            int currentCount = ProfileStackPanel.Children.Count;
            ProfileCountLabel.Content = $"{currentCount}/4";
        }
        private void Button_Click(object sender, RoutedEventArgs e) // 진단결과
        {
            MyTabControl.SelectedIndex = 7;
        }
        private async void Creat_Profile_btn(object sender, RoutedEventArgs e)
        {
            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버 연결이 없습니다.");
                return;
            }

            if (ProfileStackPanel.Children.Count >= 4)
            {
                MessageBox.Show("프로필은 최대 4개까지만 생성할 수 있습니다.");
                return;
            }

            var inputWindow = new MyProfileInputWindow
            {
                Owner = this
            };
            bool? dialogResult = inputWindow.ShowDialog();

            if (dialogResult == true)
            {
                string nickname = inputWindow.Nickname;
                string birth = inputWindow.Birth;
                string gender = inputWindow.Gender;

                if (string.IsNullOrWhiteSpace(nickname) ||
                    string.IsNullOrWhiteSpace(birth) ||
                    string.IsNullOrWhiteSpace(gender))
                {
                    MessageBox.Show("모든 정보를 입력해주세요.");
                    return;
                }

                var jsonObj = new
                {
                    signal = "profile_create",
                    id = myid,
                    nickname = nickname,
                    birth = birth,
                    gender = gender
                };

                string json = JsonSerializer.Serialize(jsonObj) + "\n";

                try
                {
                    byte[] data = Encoding.UTF8.GetBytes(json);
                    await stream.WriteAsync(data, 0, data.Length);

                    // 응답 대기
                    byte[] buffer = new byte[1024];
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    var responseObj = JsonSerializer.Deserialize<JsonElement>(response);
                    string signal = responseObj.GetProperty("signal").GetString();
                    string result = responseObj.GetProperty("result").GetString(); 

                    if (signal == "profile_success" && result == "0")
                    {
                        // ✅ Border + StackPanel 조합으로 UI 추가
                        StackPanel profilePanel = new StackPanel
                        {
                            Orientation = Orientation.Vertical
                        };
                        profilePanel.Children.Add(new TextBlock { Text = $"닉네임: {nickname}", FontWeight = FontWeights.Bold });
                        profilePanel.Children.Add(new TextBlock { Text = $"생년월일: {birth}" });
                        profilePanel.Children.Add(new TextBlock { Text = $"성별: {gender}" });

                        Border border = new Border
                        {
                            Child = profilePanel,
                            Padding = new Thickness(10),
                            Background = Brushes.White, // 배경 흰색
                            BorderBrush = new SolidColorBrush(Color.FromRgb(230, 230, 230)), // 연한 흰색 (약간 회색 느낌)
                            BorderThickness = new Thickness(1),
                            CornerRadius = new CornerRadius(6),
                            Margin = new Thickness(5)
                        };

                        // 🔘 프로필 클릭 이벤트도 추가 가능 (예: 선택 효과)
                        border.MouseLeftButtonUp += (s, ev) =>
                        {
                            myname = nickname;
                            MyTabControl.SelectedIndex = 3;
                            //MessageBox.Show($"[{nickname}] 프로필을 선택했습니다.");
                        };

                        ProfileStackPanel.Children.Add(border);
                        UpdateProfileCountLabel();
                    }
                    else
                    {
                        MessageBox.Show("프로필 생성 실패");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("프로필 생성 중 오류: " + ex.Message);
                }
            }
        }
        private async void Record_Button_Click(object sender, RoutedEventArgs e)
        {
            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버 연결이 없습니다.");
                return;
            }

            var jsonObj = new
            {
                signal = "reload_chat",
                id = myid,
                name = myname
            };

            string json = JsonSerializer.Serialize(jsonObj) + "\n";
            byte[] data = Encoding.UTF8.GetBytes(json);

            try
            {
                await stream.WriteAsync(data, 0, data.Length);

                byte[] buffer = new byte[4096];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                var doc = JsonDocument.Parse(response);
                var root = doc.RootElement;

                string signal = root.GetProperty("signal").GetString();

                if (signal == "reload_chat_result")
                {
                    if (root.TryGetProperty("data", out JsonElement dataArray) && dataArray.ValueKind == JsonValueKind.Array)
                    {
                        ShowChatRecords(dataArray); // 🟢 여기에서 UI 추가
                    }
                    else
                    {
                        MessageBox.Show("데이터 형식 오류");
                    }
                }
                else
                {
                    MessageBox.Show($"예상치 못한 signal: {signal}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"채팅 불러오기 오류: {ex.Message}");
            }
            MyTabControl.SelectedIndex = 4;
        }
        private string currentChatTimestamp = null;
        private void ShowChatRecords(JsonElement chatDataArray)
        {
            Dispatcher.Invoke(() =>
            {
                RecordStackPanel.Children.Clear();

                foreach (JsonElement item in chatDataArray.EnumerateArray())
                {
                    string timestamp = item.GetProperty("timestamp").GetString();

                    var textBlock = new TextBlock
                    {
                        Text = timestamp,
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(10),
                        FontSize = 14,
                        FontWeight = FontWeights.SemiBold
                    };

                    var border = new Border
                    {
                        Width = 350,         
                        Height = 70,        
                        Child = textBlock,
                        Background = Brushes.White, // 배경 흰색
                        BorderBrush = new SolidColorBrush(Color.FromRgb(230, 230, 230)), 
                        BorderThickness = new Thickness(1),
                        CornerRadius = new CornerRadius(10),
                        Margin = new Thickness(5),
                        Padding = new Thickness(10),
                        HorizontalAlignment = HorizontalAlignment.Left,
                        Cursor = Cursors.Hand // 클릭 가능한 느낌 주기
                    };

                    
                    border.MouseLeftButtonUp += async (s, ev) =>
                    {
                        currentChatTimestamp = timestamp; // 클릭한 채팅 기록의 timestamp 저장
                        MyTabControl.SelectedIndex = 6;
                        await LoadChatDetailAsync(timestamp);
                    };

                    RecordStackPanel.Children.Add(border);
                }
            });
        }
        private async Task LoadChatDetailAsync(string timestamp)
        {
            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버 연결이 끊어졌습니다.");
                return;
            }

            try
            {
                var requestObj = new
                {
                    signal = "chat_detail_request",
                    id = myid,
                    name = myname,
                    timestamp = timestamp
                };

                string json = JsonSerializer.Serialize(requestObj) + "\n";
                byte[] data = Encoding.UTF8.GetBytes(json);
                await stream.WriteAsync(data, 0, data.Length);

                byte[] buffer = new byte[8192];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                //MessageBox.Show(response, "서버에서 받은 JSON");

                var responseObj = JsonSerializer.Deserialize<JsonElement>(response);

                string signal = responseObj.GetProperty("signal").GetString();
                if (signal == "chat_detail_response")
                {
                    JsonElement messages = responseObj.GetProperty("messages");
                    ShowChatMessages(messages);
                }
                else
                {
                    MessageBox.Show("채팅 기록 불러오기 실패");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("채팅 기록 요청 중 오류: " + ex.Message);
            }
        }
        private async Task DeleteChatRecordAsync() // 채팅기록삭제
        {
            if (string.IsNullOrEmpty(currentChatTimestamp))
            {
                MessageBox.Show("삭제할 채팅 기록이 선택되지 않았습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show("정말로 이 채팅 기록을 삭제하시겠습니까?", "확인", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버 연결이 끊어졌습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var requestObj = new
                {
                    signal = "record_delete",
                    id = myid,
                    name = myname,
                    timestamp = currentChatTimestamp
                };

                string json = JsonSerializer.Serialize(requestObj) + "\n";
                byte[] data = Encoding.UTF8.GetBytes(json);
                await stream.WriteAsync(data, 0, data.Length);

                // 서버 응답 받기
                byte[] buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                var responseObj = JsonSerializer.Deserialize<JsonElement>(response);

                string signal = responseObj.GetProperty("signal").GetString();
                string resultCode = responseObj.GetProperty("result").GetString();

                if (signal == "delete_result" && resultCode == "0")
                {
                    MessageBox.Show("채팅 기록이 삭제되었습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);

                    // ✅ UI에서 해당 채팅 박스도 제거
                    RemoveRecordByTimestamp(currentChatTimestamp);

                    // ✅ 기록 목록 탭으로 이동
                    MyTabControl.SelectedIndex = 4;

                    currentChatTimestamp = null; // 현재 선택 해제
                }
                else
                {
                    MessageBox.Show("삭제에 실패했습니다.", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("삭제 요청 중 오류 발생: " + ex.Message, "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void RemoveRecordByTimestamp(string timestamp)
        {
            foreach (var item in RecordStackPanel.Children)
            {
                if (item is Border border && border.Child is TextBlock textBlock)
                {
                    if (textBlock.Text == timestamp)
                    {
                        RecordStackPanel.Children.Remove(border);
                        break;
                    }
                }
            }
        }

        private void ShowChatMessages(JsonElement messagesArray)
        {
            Dispatcher.Invoke(() =>
            {
                Record_chat_StackPanel.Children.Clear();

                int index = 0;
                foreach (JsonElement msg in messagesArray.EnumerateArray())
                {
                    string content = msg.GetString();

                    var textBlock = new TextBlock
                    {
                        Text = content,
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(5),
                        FontSize = 14,
                        Foreground = Brushes.Black
                    };

                    var border = new Border
                    {
                        Child = textBlock,
                        BorderBrush = Brushes.Gray,
                        BorderThickness = new Thickness(1),
                        CornerRadius = new CornerRadius(5),
                        Margin = new Thickness(5),
                        Padding = new Thickness(5),
                        Background = (index % 2 == 0) ? Brushes.LightGray : Brushes.LightSkyBlue, // 짝수=유저 회색, 홀수=서버 하늘색
                        HorizontalAlignment = (index % 2 == 0) ? HorizontalAlignment.Left : HorizontalAlignment.Right // 짝수=왼쪽, 홀수=오른쪽
                    };

                    Record_chat_StackPanel.Children.Add(border);
                    index++;
                }
            });
        }

        private void Record_chat_back_btn_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 4;
        }
        private void go_to_map(object sender, RoutedEventArgs e)
        {
            MainWindow_Loaded();
            
            MyTabControl.SelectedIndex = 7;
        }
        private async void MainWindow_Loaded()
        {
            await webView.EnsureCoreWebView2Async();


            string htmlPath = System.IO.Path.Combine(AppContext.BaseDirectory, "map.html");
            webView.Source = new Uri(htmlPath);

            webView.CoreWebView2.Settings.IsWebMessageEnabled = true;
            // 1. 메시지 수신 핸들러 등록

            webView.CoreWebView2.WebMessageReceived += WebView_WebMessageReceived;


            // 2. HTML 로드 완료 시 JavaScript 함수 호출
            webView.NavigationCompleted += async (s, args) =>
            {
                string escapedAddress = address.Replace("\\", "\\\\").Replace("'", "\\'");
                await webView.ExecuteScriptAsync($"resolveAddressOrKeyword('{escapedAddress}')");
                RequestHospitals();
            };
        }

        private async void RequestHospitals()
        {
            if (stream == null || !client.Connected)
            {
                MessageBox.Show("서버와 연결되어 있지 않습니다.");
                return;
            }

            // 1. 요청 JSON 구성
            var jsonObj = new
            {
                signal = "req_hop",
                id = myid,
                addr = address,
                x = X_CDN.ToString(),
                y = Y_CDN.ToString()

            };
            string json = JsonSerializer.Serialize(jsonObj) + "\n";
            byte[] data = Encoding.UTF8.GetBytes(json);

            try
            {
                // 2. 서버로 전송
                await stream.WriteAsync(data, 0, data.Length);

                // 3. 응답 수신
                byte[] buffer = new byte[100000];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                // 4. 파싱
                var doc = JsonDocument.Parse(response);
                var root = doc.RootElement;

                if (root.GetProperty("signal").GetString() == "req_hop_result")
                {
                    var dataArray = root.GetProperty("hospital"); // 서버에서 보내는 key가 "hospital"이라고 가정

                    var hospitalList = new List<Hospital>();

                    foreach (var item in dataArray.EnumerateArray())
                    {
                        var hospital = new Hospital
                        {
                            HOP_NAME = item.GetProperty("name").GetString(),
                            HOPE_ADDR = item.GetProperty("address").GetString(),
                            X_CDN = double.Parse(item.GetProperty("x").GetString()),
                            Y_CDN = double.Parse(item.GetProperty("y").GetString()),
                            TYPE_CODE = item.GetProperty("type_code").GetString(),
                            TREAT_CODE = item.GetProperty("treat_code").GetString(),
                            NUM_SPC = item.GetProperty("num_spc").GetString(),
                            HOP_PNUM = item.GetProperty("phone").GetString()
                        };

                        hospitalList.Add(hospital);
                    }

                    // 5. 병원 리스트 반영
                    allHospitals = hospitalList;
                    CreateFilterCheckboxes();
                    UpdateMapAndList(allHospitals);
                }
                else
                {
                    MessageBox.Show("예상하지 못한 signal입니다.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("병원 정보 요청 중 오류: " + ex.Message);
            }
        }


        // 3. JS → C# 메시지 수신
        private void WebView_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                string msg = e.TryGetWebMessageAsString();

                if (!string.IsNullOrEmpty(msg))
                {
                    // 문자열이 JSON처럼 생겼는지 확인
                    if (msg == "go_back")
                    {
                        //MessageBox.Show("go_back 문자열 수신됨!");

                        Dispatcher.Invoke(() =>
                        {
                            MyTabControl.SelectedIndex = 1;
                        });
                        return;
                    }
                }

                // 문자열 아니면 JSON 파싱 시도
                string json = e.WebMessageAsJson;

                // JSON 유효성 체크: 반드시 객체여야 함 (예: { "x": 123, "y": 456 })
                if (!json.TrimStart().StartsWith("{"))
                {
                    MessageBox.Show("유효하지 않은 JSON 메시지입니다.");
                    return;
                }

                var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                if (root.TryGetProperty("x", out var xElem) &&
                    root.TryGetProperty("y", out var yElem))
                {
                    X_CDN = xElem.GetDouble();
                    Y_CDN = yElem.GetDouble();
                    Console.WriteLine($"좌표 변환 결과: {X_CDN}, {Y_CDN}");
                }
                else if (root.TryGetProperty("error", out var errElem))
                {
                    MessageBox.Show(errElem.GetString(), "주소 변환 실패");
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("WebMessage 파싱 오류: " + ex.Message);
            }
        }

        private void Checkbox_Checked(object sender, RoutedEventArgs e)
        {
            var clickedCb = sender as CheckBox;

            // Treat 패널일 경우
            if (TreatCodeFilterPanel.Children.Contains(clickedCb))
            {
                foreach (CheckBox cb in TreatCodeFilterPanel.Children.OfType<CheckBox>())
                {
                    if (cb != clickedCb) cb.IsChecked = false;
                }
            }

            // Grade 패널일 경우
            if (GradeFilterPanel.Children.Contains(clickedCb))
            {
                foreach (CheckBox cb in GradeFilterPanel.Children.OfType<CheckBox>())
                {
                    if (cb != clickedCb) cb.IsChecked = false;
                }
            }

            // 필터 적용
            ApplyCombinedFilters();
        }

        private void CreateFilterCheckboxes()
        {
            var treatCodes = allHospitals.Select(h => h.TREAT_CODE).Distinct();
            foreach (var code in treatCodes)
            {
                var cb = CreateCheckbox(code, h => h.TREAT_CODE == code);
                TreatCodeFilterPanel.Children.Add(cb);
            }

            var type1 = CreateCheckbox("1등급 병원", h => h.TYPE_CODE == "1" || h.TYPE_CODE == "11");
            var type2 = CreateCheckbox("2등급 병원", h => h.TYPE_CODE != "1" && h.TYPE_CODE != "11" && h.NUM_SPC != "0");
            var type3 = CreateCheckbox("3등급 병원", h => h.TYPE_CODE != "1" && h.TYPE_CODE != "11" && h.NUM_SPC == "0");

            GradeFilterPanel.Children.Add(type1);
            GradeFilterPanel.Children.Add(type2);
            GradeFilterPanel.Children.Add(type3);
        }

        private CheckBox CreateCheckbox(string label, Func<Hospital, bool> filter)
        {
            var cb = new CheckBox
            {
                Content = label,
                Margin = new Thickness(8, 0, 8, 0),
                Style = CreateStyledCheckbox()
            };
            cbFilters[cb] = filter;

            cb.Checked += Checkbox_Checked;
            cb.Unchecked += (s, e) => ApplyCombinedFilters(); // 필터 해제도 적용 필요
            return cb;
        }



        private Style CreateStyledCheckbox()
        {
            var style = new Style(typeof(CheckBox));

            style.Setters.Add(new Setter(Control.FontSizeProperty, 14.0));
            style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.Gray));

            style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(5, 0, 5, 0)));
            style.Setters.Add(new Setter(Control.CursorProperty, Cursors.Hand));

            style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0.5)));
            style.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.SteelBlue));
            style.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
            style.Setters.Add(new Setter(Control.TemplateProperty, CreateCheckboxTemplate()));

            return style;
        }

        private ControlTemplate CreateCheckboxTemplate()
        {
            string xaml = @"
<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                 xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
                 TargetType='CheckBox'>
    <Border x:Name='Border'
            BorderThickness='{TemplateBinding BorderThickness}'
            CornerRadius='4'
            BorderBrush='{TemplateBinding BorderBrush}'
            Background='{TemplateBinding Background}'
            Padding='{TemplateBinding Padding}'>
        <StackPanel Orientation='Horizontal'>
            <ContentPresenter VerticalAlignment='Center' />
        </StackPanel>
    </Border>
    <ControlTemplate.Triggers>
        <Trigger Property='IsChecked' Value='True'>
            <Setter TargetName='Border' Property='Background' Value='#2F6BF7'/>
            <Setter Property='Foreground' Value='White'/>
        </Trigger>
    </ControlTemplate.Triggers>
</ControlTemplate>";
            return (ControlTemplate)XamlReader.Parse(xaml);
        }

        private void ApplyCombinedFilters()
        {
            // Treat 필터
            Func<Hospital, bool> treatFilter = null;
            var treatChecked = TreatCodeFilterPanel.Children.OfType<CheckBox>().FirstOrDefault(cb => cb.IsChecked == true);
            if (treatChecked != null)
            {
                treatFilter = cbFilters[treatChecked]; // 아래에서 Dictionary로 연결
            }

            // Grade 필터
            Func<Hospital, bool> gradeFilter = null;
            var gradeChecked = GradeFilterPanel.Children.OfType<CheckBox>().FirstOrDefault(cb => cb.IsChecked == true);
            if (gradeChecked != null)
            {
                gradeFilter = cbFilters[gradeChecked];
            }

            // 필터 조합: AND 처리
            var filtered = allHospitals.Where(h =>
                (treatFilter == null || treatFilter(h)) &&
                (gradeFilter == null || gradeFilter(h))
            ).ToList();

            UpdateMapAndList(filtered);
        }

        private async void UpdateMapAndList(List<Hospital> hospitals)
        {
            HospitalListPanel.Children.Clear();

            foreach (var h in hospitals)
            {
                var border = new Border
                {
                    BorderBrush = Brushes.SteelBlue,
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(6),
                    Margin = new Thickness(5),
                    Padding = new Thickness(8),
                    Background = Brushes.White,
                    Effect = new DropShadowEffect
                    {
                        BlurRadius = 3,
                        ShadowDepth = 1,
                        Opacity = 0.3
                    },
                    Cursor = Cursors.Hand
                };

                var stack = new StackPanel();

                var nameText = new TextBlock
                {
                    Text = h.HOP_NAME,
                    FontWeight = FontWeights.Bold,
                    FontSize = 14,
                    Foreground = Brushes.Black
                };

                var addrText = new TextBlock
                {
                    Text = h.HOPE_ADDR,
                    FontSize = 12,
                    Foreground = Brushes.Gray,
                    Margin = new Thickness(0, 4, 0, 0)
                };

                // 전화번호와 아이콘
                var phonePanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 4, 0, 0),
                };

                var phoneIcon = new TextBlock
                {
                    Text = "\uE717", // 전화기 아이콘 (Segoe MDL2 Assets)
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    Foreground = Brushes.DeepSkyBlue,
                    FontSize = 14,
                    VerticalAlignment = VerticalAlignment.Center
                };

                var phoneText = new TextBlock
                {
                    Text = " " + h.HOP_PNUM,
                    FontSize = 12,
                    Foreground = Brushes.Gray,
                    VerticalAlignment = VerticalAlignment.Center
                };

                phonePanel.Children.Add(phoneIcon);
                phonePanel.Children.Add(phoneText);

                // 조립
                stack.Children.Add(nameText);
                stack.Children.Add(addrText);
                stack.Children.Add(phonePanel);

                border.Child = stack;
                // 👇 클릭 이벤트 연결: 해당 병원의 위치로 지도 이동
                border.MouseLeftButtonUp += async (s, e) =>
                {
                    string script = $"moveToHospital({h.X_CDN}, {h.Y_CDN});";
                    await webView.ExecuteScriptAsync(script);
                };

                HospitalListPanel.Children.Add(border);

            }

            // 마커 표시
            string json = JsonSerializer.Serialize(hospitals);
            string scriptAll = $"showHospitals(JSON.parse('{json.Replace("\\", "\\\\").Replace("'", "\\'")}'));";
            await webView.ExecuteScriptAsync(scriptAll);
        }


        private void Setting2_btn(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 11;
        }

        private async void Delete_btn_Click(object sender, RoutedEventArgs e)
        {
            await DeleteChatRecordAsync();
        }
        private void MascotButton_Click(object sender, RoutedEventArgs e)
        {
            string videoPath = System.IO.Path.Combine(AppContext.BaseDirectory, "video", "C:\\Users\\나\\source\\repos\\Apayo\\image\\mascot_movie.mp4");

            if (!System.IO.File.Exists(videoPath))
            {
                MessageBox.Show("동영상 파일이 없습니다: " + videoPath);
                return;
            }

            var videoWindow = new VideoWindow(videoPath)
            {
                Owner = this  // 메인창을 부모로 지정하면 팝업 느낌 더 좋아짐
            };
            videoWindow.ShowDialog();
        }

        private void start1_btn1(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 9;
        }

        private void start2_btn2(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 0;
        }

        private void warn_btn1(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 3;
        }

        private void setting_back_btn_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 3;
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "정말 로그아웃하시겠습니까?",
                "로그아웃 확인",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MyTabControl.SelectedIndex = 0; // 실제 로그아웃 처리
            }
        }

        private void profil_Click(object sender, RoutedEventArgs e)
        {
            MyTabControl.SelectedIndex = 5;
        }
    }
    public class Hospital
    {
        public string HOP_NAME { get; set; }
        public string TYPE_CODE { get; set; }
        public string HOPE_ADDR { get; set; }
        public string HOP_PNUM { get; set; }
        public double X_CDN { get; set; }
        public double Y_CDN { get; set; }
        public string TREAT_CODE { get; set; }
        public string NUM_SPC { get; set; }
    }
}
