﻿using System;
using System.Windows;

namespace Apayo
{
    public partial class IntroWindow : Window
    {
        public IntroWindow()
        {
            InitializeComponent();

            // 영상 경로 설정 (절대경로 아님, 상대경로 사용 권장)
            string videoPath = System.IO.Path.Combine(AppContext.BaseDirectory, "image", "RedBear_Subway.mp4");
            IntroVideo.Source = new Uri(videoPath);
            IntroVideo.Play();
        }

        private void IntroVideo_MediaEnded(object sender, RoutedEventArgs e)
        {
            OpenMainWindow();
        }

        private void IntroVideo_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenMainWindow();
        }

        private void Window_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            OpenMainWindow();
        }

        private void OpenMainWindow()
        {
            if (!AppIsAlreadyStarted) // 영상 끝나기 전에 연속 클릭 방지
            {
                AppIsAlreadyStarted = true;
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }

        private bool AppIsAlreadyStarted = false;
    }
}
