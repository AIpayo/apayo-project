﻿using System.Windows;
using System.Windows.Controls;

namespace Apayo
{
    public partial class MyProfileInputWindow : Window
    {
        public string Nickname => NicknameBox.Text.Trim();
        public string Birth => BirthBox.Text.Trim();
        public string Gender => (GenderComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

        public MyProfileInputWindow()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Nickname) || string.IsNullOrWhiteSpace(Birth) || string.IsNullOrWhiteSpace(Gender))
            {
                MessageBox.Show("모든 항목을 입력하세요.");


                return;
            }

            DialogResult = true;
        }
    }
}
