﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Apayo
{
    public partial class VideoWindow : Window
    {
        public VideoWindow(string videoPath)
        {
            InitializeComponent();

            VideoPlayer.Source = new Uri(videoPath);
            VideoPlayer.MediaEnded += (s, e) => this.Close();
            VideoPlayer.Play();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            VideoPlayer.Stop();
            this.Close();
        }
    }
}
